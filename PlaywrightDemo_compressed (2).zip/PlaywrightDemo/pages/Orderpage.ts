import { Page ,expect} from '@playwright/test';
import { OrderReader } from '../utils/OrderReader';
 
export class OrderPage {
 
    constructor(private page: Page) {}
    async handleDuplicateOrderPopup() {
        try {
    await this. page.locator("//h3[contains(normalize-space(),'Duplicate Order')]")
        .waitFor({ state: 'visible', timeout: 2000 });
 
    await this.page.locator("//button[normalize-space()='Ok']").click();
 
    console.log("Duplicate Order popup handled");
} catch {
    console.log("No Duplicate Order popup");
}
    }
   
 
    async createOrder(
        outletName: string,
        products: { productcode: string; Qty: number }[]



       // qty: string

    )
    {
    await this.page.getByRole('button', { name: 'C l ose' }).click();
   // await this.purchasepopupclose();
    await this.page.getByRole('button', { name: 'Transactions' }).hover();
    await this.page.locator('#offcanvasNavbar').getByText('Orders').click();
    await this.page.getByRole('button', { name: 'V iew' }).click();
    await this.page.locator("//div[p[normalize-space()='Orders']]").click();
    await this.page.getByRole('button', { name: 'C reate PO & Bill' }).click();
   
      //Outlet
     await this.page.getByRole('combobox', { name: 'Select Retailer' }).click();
     await this.page.getByText(outletName).click();
     await this.handleDuplicateOrderPopup()

     
 
     //Add SKU
    // await this.page.getByText('Add SKU (alt + P)').click();
 
    // // Product Code
    // await this.page.getByText(productcode).click();
 

    // // Quantity
    // const row = this.page.getByRole('row', { name: new RegExp(productcode) });

    for (const item of products) {

  // Step 1: Click Add SKU
  await this.page.getByText('Add Product (alt + P)').click();

  // Step 2: Select product
    await this.page.getByText(item.productcode.toString())
    

  // Step 3: Wait for row to appear
    const row = this.page.locator('tr.k-master-row').filter({
    hasText: item.productcode
  }).last();

    await row.waitFor({ state: 'visible' });
    await row.getByRole('textbox').fill(item.Qty.toString() );
    await this.page.waitForTimeout(1000);
    await row.getByRole('textbox').press('Enter');
    //await this.page.getByRole('button', { name: 'Convert To   B ill' }).click();
  
    await this.page.waitForTimeout(1000);
    
    }
}
    // validate footer

  async getAllFooterValues() {
    const values = await this.page
        .locator('span.dms-bottom-val')
        .allTextContents();

    const numbers = values.map(v => Number(v.trim()));

    console.log('All UI footer Values:', numbers);

    return {
    grossAmt: numbers[0],          // 204.30
    schemeDiscount: numbers[1],    // 0.00
    cashDiscount: numbers[2],         // 0.00
    starDiscount: numbers[3],         // 0.00
    taxAmount: numbers[4],         // 36.78
    cessamt: numbers[5],           // 0.00
    tcsamt: numbers[6],            // 0.00
    billamt: numbers[10],          // 241.00 ✅
    creditnoteamt: numbers[8],     // 0.00
    rounding: numbers[9],          // -0.08
    netamt: numbers[7],            // 241.08 ✅
    totalqty: numbers[11],         // 30
};
}
   

    async createbill()
    {
       await this.page.getByRole('button', { name: 'Convert To   B ill' }).click();
      await this.page.getByRole('button', { name: 'Nex t' }).click();
      await this.page.getByRole('button', { name: 'Create   B ill' }).click();
      await this.page.getByRole('button', { name: 'Sa l es' }).click();
       await this.page.waitForTimeout(1000);
    }

    

}

