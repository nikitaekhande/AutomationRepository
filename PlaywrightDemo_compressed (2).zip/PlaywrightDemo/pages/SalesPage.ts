import { Page ,expect} from '@playwright/test';
import { OrderReader } from '../utils/OrderReader';
import { OrderPage } from './Orderpage';
import { LoginPage } from './Loginpage';

export class SalesPage {
    constructor(private page: Page) {}


    async viewsalesbill() {
        


    }
}
