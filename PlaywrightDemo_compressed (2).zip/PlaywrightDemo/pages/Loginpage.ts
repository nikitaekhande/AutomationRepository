
import { Page } from '@playwright/test';
import Tesseract from 'tesseract.js';
 
export class LoginPage {
  constructor(public page: Page) {}
 
  async login() {
    await this.page.goto('https://darpanmfeuat.hspldms.com/#/');
    // await this.page.getByRole('textbox', { name: 'WSS Code' }).click();
  await this.page.getByRole('textbox', { name: 'Distributor Code' }).fill('0001000197');
 // await this.page.getByRole('textbox', { name: 'WSS Code' }).press('ControlOrMeta+a');
  await this.page.getByRole('textbox', { name: 'User ID' }).click();
  //await this.page.getByRole('textbox', { name: 'User ID' }).click();
  await this.page.getByRole('textbox', { name: 'User ID' }).fill('0001000197');
  //await this.page.getByRole('textbox', { name: 'Password' }).click();
  //await this.page.getByRole('textbox', { name: 'Password' }).press('CapsLock');
  //await this.page.getByRole('textbox', { name: 'Password' }).fill('A');
 // await this.page.getByRole('textbox', { name: 'Password' }).press('CapsLock');
  await this.page.getByRole('textbox', { name: 'Password' }).fill('Darpan@123');
 // await this.page.getByRole('textbox', { name: 'PIN' }).click();
  await this.page.getByRole('textbox', { name: 'PIN' }).fill('122234');
 
    // Capture captcha

    for (let i = 0; i < 2; i++){
    const captchaImage = this.page.locator('#captcahCanvas');
await captchaImage.screenshot({ path: 'captcha.png' });
 
  // Read captcha using OCR
  const result = await Tesseract.recognize(
    'captcha.png',
    'eng'
  );
 
  const captchaText = result.data.text.trim();
 
  console.log('Captcha:', captchaText);
 
  await this.page.getByRole('textbox', { name: 'Enter Captcha' })
    .fill(captchaText);
 // await this.page.waitForTimeout(2000);
  await this.page.getByRole('button', { name: 'Continue' }).click();
 await this.page.waitForTimeout(5000);

//check error msg
const error = this.page.locator('text=The information you entered is incorrect. Please try again.');
 if (await error.isVisible({ timeout: 3000 }).catch(() => false)) {
      console.log("Wrong captcha, retry...");
       // 🔄 Refresh captcha
     await this.page.getByRole('link').click();
}
  else{
    console.log("Login success");
  }
}
   
  }
}

 