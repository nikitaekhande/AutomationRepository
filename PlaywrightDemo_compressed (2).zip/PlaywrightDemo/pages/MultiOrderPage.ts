import { Page ,expect} from '@playwright/test';
import { OrderReader } from '../utils/OrderReader';
import { OrderPage } from './Orderpage';
import { LoginPage } from './Loginpage';

export class multiOrderPage {
    constructor(private page: Page) {}

    

    async handleDuplicateOrderPopup() {
        try {
    await this. page.locator("//h3[contains(normalize-space(),'Duplicate Order')]")
        .waitFor({ state: 'visible', timeout: 2000 });
 
    await this.page.locator("//button[normalize-space()='Ok']").click();
 
    console.log("Duplicate Order popup handled");
} catch {
    console.log("No Duplicate Order popup");
}
    }
async handlepurchasepopupclose() {
  const closeBtn = this.page.getByRole('button', { name: 'C l ose' });

  try {
    await closeBtn.waitFor({ state: 'visible', timeout: 3000 });
    await closeBtn.click();
  } catch {
    console.log("Popup not appeared");
  }
}
     
    async createMultiOrder(data: any[])
    {
   //  const data: any[] = OrderReader.getData(sheetName);

  // 🔹 Step 2: Group by outlet
  const outletMap = new Map<string, { productcode: string; Qty: number }[]>();
  let orderPage = new OrderPage(this.page);

  for (const row of data) {

    if (!outletMap.has(row.Outletname)) {
      outletMap.set(row.Outletname, []);
    }

    outletMap.get(row.Outletname)?.push({
      productcode: row.productcode,
      Qty: Number(row.Qty)
    });
  }

  // 🔹 Step 3: Loop all outlets
  for (const [outletName, products] of outletMap) {

    // ✅ Create Order (your existing method)
   await orderPage.createOrder(outletName, products);

    // ✅ Create Bill
    await orderPage.createbill();



    
    }
   }
}