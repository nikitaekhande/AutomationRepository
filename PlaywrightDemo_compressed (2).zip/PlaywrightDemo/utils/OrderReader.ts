import * as XLSX from 'xlsx';
 
export class OrderReader {
 
    static getData(sheetName: string) {
 
        const workbook = XLSX.readFile('./testData/onlinedms.xlsx');
 
        const worksheet = workbook.Sheets[sheetName];
 
        return XLSX.utils.sheet_to_json(worksheet);
    }
}