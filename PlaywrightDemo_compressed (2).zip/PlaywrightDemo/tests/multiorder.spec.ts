import { multiOrderPage } from '../pages/MultiOrderPage';
import { expect, test,Page } from '@playwright/test';
import { OrderReader } from '../utils/OrderReader';
import { LoginPage } from '../pages/Loginpage';
import { OrderPage } from '../pages/Orderpage';

test('Multi order End to End order flow', async ({ page }: { page: Page }) => {
let multiOrderPageInstance: multiOrderPage;
let loginPage: LoginPage;
let orderPage: OrderPage;

    
    loginPage = new LoginPage(page);
    orderPage = new OrderPage(page);
    multiOrderPageInstance = new multiOrderPage(page);
    await loginPage.login();
    await multiOrderPageInstance.handlepurchasepopupclose();
   // test.setTimeout(60000);
    const data: any = OrderReader.getData('Sheet2');
    
    await multiOrderPageInstance.createMultiOrder(data);
   




});