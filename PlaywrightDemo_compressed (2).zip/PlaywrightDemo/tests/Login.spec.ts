
import { test } from '@playwright/test';
import { LoginPage } from '../pages/Loginpage';
 
test('User Sucessful Login to the application', async ({ page }) => {
  const loginPage = new LoginPage(page);
 
  await loginPage.login();
});
 
