// import { test } from '@playwright/test';
// import { LoginPage } from '../pages/Loginpage';
// import { OrderPage } from '../pages/Orderpage';
// import { OrderReader } from '../utils/OrderReader';
 
 
// test('End to End order flow', async ({ page }) => {
//    const loginPage = new LoginPage(page);
//    const orderPage = new OrderPage(page);
   
//     //step 1 :
//     await loginPage.login();
//     const data: any = OrderReader.getData('Sheet1');
//     const row = data[0];
 
//     //step 2:
//     await orderPage.createOrder(
//         row.Outletname,
//         row.productcode,
//         row.Qty.toString()
//     );
//  // await orderPage.ValidateFooter(data);
//   await orderPage.createbill();
  
// });


import { expect, test } from '@playwright/test';
import { LoginPage } from '../pages/Loginpage';
import { OrderPage } from '../pages/Orderpage';
import { OrderReader } from '../utils/OrderReader';


//Test 1

test.describe.serial('End to End order flow', () => { 
   test.setTimeout(120000);
  let orderPage: OrderPage;
  let loginPage: LoginPage;
  let row: any;
  let page: any;

  test.beforeAll(async ({ browser }) => {
     page = await browser.newPage();
    loginPage = new LoginPage(page);
    orderPage = new OrderPage(page);
   // test.setTimeout(2000); 

    const data: any = OrderReader.getData('Sheet1');
    const outletName = data[0].Outletname;

// ✅ Convert Excel → products array
const products = data
  .filter((item: any) => item.productcode && item.Qty)
  .map((item: any) => ({
    productcode: item.productcode,
    Qty: Number(item.Qty)
  }));
  //common step
await loginPage.login();

// ✅ Call createOrder with ALL products
await orderPage.createOrder(outletName, products);

// Keep first row for validation
 row = data[0];
  });
  
  test('Validate Footer Amounts', async ({ page }) => {

    const actualAmount: any = await orderPage.getAllFooterValues();

    // Replace GrossAmount with your actual Excel column name
    const expectedGrossAmount = Number(row.grossAmt);
    const expectedSchemeDiscount = Number(row.schemeDiscount);
    const expectedCashDiscount = Number(row.cashDiscount);
    const expectedStarDiscount = Number(row.starDiscount);
    const expectedTaxAmount = Number(row.taxAmount);
    const expectedCessAmt = Number(row.cessamt);
    const expectedTcsAmt = Number(row.tcsamt);
    const expectedCreditNoteAmt = Number(row.creditnoteamt);
    const expectedRounding = Number(row.rounding);
    const expectedBillAmount = Number(row.billamt);
    const expectedNetAmount = Number(row.netamt);
    const expectedTotalQTY = Number(row.totalqty);

    expect(actualAmount.grossAmt).toBeCloseTo(expectedGrossAmount, 2);
    expect(actualAmount.schemeDiscount).toBeCloseTo(expectedSchemeDiscount, 2);
    expect(actualAmount.cashDiscount).toBeCloseTo(expectedCashDiscount, 2);
    expect(actualAmount.starDiscount).toBeCloseTo(expectedStarDiscount, 2);
    expect(actualAmount.taxAmount).toBeCloseTo(expectedTaxAmount, 2);
    expect(actualAmount.cessamt).toBeCloseTo(expectedCessAmt, 2);
    expect(actualAmount.tcsamt).toBeCloseTo(expectedTcsAmt, 2);
    expect(actualAmount.creditnoteamt).toBeCloseTo(expectedCreditNoteAmt, 2);
    expect(actualAmount.rounding).toBeCloseTo(expectedRounding, 2);
    expect(actualAmount.billamt).toBeCloseTo(expectedBillAmount, 2);
    expect(actualAmount.netamt).toBeCloseTo(expectedNetAmount, 2);
    expect(actualAmount.totalqty).toBeCloseTo(expectedTotalQTY, 2);

});


  // ✅ Test 2
  test('Create Bill', async () => {
    await orderPage.createbill();
   
  });





});
