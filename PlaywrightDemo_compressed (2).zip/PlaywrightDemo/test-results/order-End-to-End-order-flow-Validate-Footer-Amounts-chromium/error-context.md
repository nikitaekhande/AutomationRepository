# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: order.spec.ts >> End to End order flow >> Validate Footer Amounts
- Location: tests\order.spec.ts:69:7

# Error details

```
"beforeAll" hook timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e11]:
  - generic [ref=e17]:
    - generic [ref=e18]: Welcome to Darpan UAT
    - textbox "WSS Code" [ref=e20]: "0001000197"
    - textbox "User ID" [ref=e22]: "0001000197"
    - generic [ref=e23]:
      - textbox "Password" [ref=e24]: Darpan@123
      - paragraph [ref=e25]: Forgot / Reset Password?
    - textbox "PIN" [ref=e27]: "122234"
    - generic [ref=e31]: Resend PIN
    - generic [ref=e32]:
      - generic [ref=e33]: Captcha
      - link [ref=e38] [cursor=pointer]:
        - /url: javascript:void(0)
        - img [ref=e39]
    - textbox "Enter Captcha" [ref=e41]: "39061"
    - button "Continue" [active] [ref=e43] [cursor=pointer]
  - generic [ref=e45]:
    - paragraph [ref=e46]: Designed & Developed by
    - paragraph [ref=e47]: Heera Software Private Limited
    - paragraph [ref=e48]: Ver. 9.1.0
```

# Test source

```ts
  1   | // import { test } from '@playwright/test';
  2   | // import { LoginPage } from '../pages/Loginpage';
  3   | // import { OrderPage } from '../pages/Orderpage';
  4   | // import { OrderReader } from '../utils/OrderReader';
  5   |  
  6   |  
  7   | // test('End to End order flow', async ({ page }) => {
  8   | //    const loginPage = new LoginPage(page);
  9   | //    const orderPage = new OrderPage(page);
  10  |    
  11  | //     //step 1 :
  12  | //     await loginPage.login();
  13  | //     const data: any = OrderReader.getData('Sheet1');
  14  | //     const row = data[0];
  15  |  
  16  | //     //step 2:
  17  | //     await orderPage.createOrder(
  18  | //         row.Outletname,
  19  | //         row.productcode,
  20  | //         row.Qty.toString()
  21  | //     );
  22  | //  // await orderPage.ValidateFooter(data);
  23  | //   await orderPage.createbill();
  24  |   
  25  | // });
  26  | 
  27  | 
  28  | import { expect, test } from '@playwright/test';
  29  | import { LoginPage } from '../pages/Loginpage';
  30  | import { OrderPage } from '../pages/Orderpage';
  31  | import { OrderReader } from '../utils/OrderReader';
  32  | 
  33  | 
  34  | //Test 1
  35  | 
  36  | test.describe.serial('End to End order flow', () => { 
  37  |    test.setTimeout(120000);
  38  |   let orderPage: OrderPage;
  39  |   let loginPage: LoginPage;
  40  |   let row: any;
  41  |   let page: any;
  42  | 
> 43  |   test.beforeAll(async ({ browser }) => {
      |        ^ "beforeAll" hook timeout of 30000ms exceeded.
  44  |      page = await browser.newPage();
  45  |     loginPage = new LoginPage(page);
  46  |     orderPage = new OrderPage(page);
  47  |    // test.setTimeout(2000); 
  48  | 
  49  |     const data: any = OrderReader.getData('Sheet1');
  50  |     const outletName = data[0].Outletname;
  51  | 
  52  | // ✅ Convert Excel → products array
  53  | const products = data
  54  |   .filter((item: any) => item.productcode && item.Qty)
  55  |   .map((item: any) => ({
  56  |     productcode: item.productcode,
  57  |     Qty: Number(item.Qty)
  58  |   }));
  59  |   //common step
  60  | await loginPage.login();
  61  | 
  62  | // ✅ Call createOrder with ALL products
  63  | await orderPage.createOrder(outletName, products);
  64  | 
  65  | // Keep first row for validation
  66  |  row = data[0];
  67  |   });
  68  |   
  69  |   test('Validate Footer Amounts', async ({ page }) => {
  70  | 
  71  |     const actualAmount: any = await orderPage.getAllFooterValues();
  72  | 
  73  |     // Replace GrossAmount with your actual Excel column name
  74  |     const expectedGrossAmount = Number(row.grossAmt);
  75  |     const expectedSchemeDiscount = Number(row.schemeDiscount);
  76  |     const expectedCashDiscount = Number(row.cashDiscount);
  77  |     const expectedStarDiscount = Number(row.starDiscount);
  78  |     const expectedTaxAmount = Number(row.taxAmount);
  79  |     const expectedCessAmt = Number(row.cessamt);
  80  |     const expectedTcsAmt = Number(row.tcsamt);
  81  |     const expectedCreditNoteAmt = Number(row.creditnoteamt);
  82  |     const expectedRounding = Number(row.rounding);
  83  |     const expectedBillAmount = Number(row.billamt);
  84  |     const expectedNetAmount = Number(row.netamt);
  85  |     const expectedTotalQTY = Number(row.totalqty);
  86  | 
  87  |     expect(actualAmount.grossAmt).toBeCloseTo(expectedGrossAmount, 2);
  88  |     expect(actualAmount.schemeDiscount).toBeCloseTo(expectedSchemeDiscount, 2);
  89  |     expect(actualAmount.cashDiscount).toBeCloseTo(expectedCashDiscount, 2);
  90  |     expect(actualAmount.starDiscount).toBeCloseTo(expectedStarDiscount, 2);
  91  |     expect(actualAmount.taxAmount).toBeCloseTo(expectedTaxAmount, 2);
  92  |     expect(actualAmount.cessamt).toBeCloseTo(expectedCessAmt, 2);
  93  |     expect(actualAmount.tcsamt).toBeCloseTo(expectedTcsAmt, 2);
  94  |     expect(actualAmount.creditnoteamt).toBeCloseTo(expectedCreditNoteAmt, 2);
  95  |     expect(actualAmount.rounding).toBeCloseTo(expectedRounding, 2);
  96  |     expect(actualAmount.billamt).toBeCloseTo(expectedBillAmount, 2);
  97  |     expect(actualAmount.netamt).toBeCloseTo(expectedNetAmount, 2);
  98  |     expect(actualAmount.totalqty).toBeCloseTo(expectedTotalQTY, 2);
  99  | 
  100 | });
  101 | 
  102 | 
  103 |   // ✅ Test 2
  104 |   test('Create Bill', async () => {
  105 |     await orderPage.createbill();
  106 |    
  107 |   });
  108 | 
  109 | 
  110 | 
  111 | 
  112 | 
  113 | });
  114 | 
```