package StepDefinations;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Hooks.WebDriverHooks;
import Utility.KeyValueDataProvider;
import Utility.Liabrary;
import WebElements.GeneralStepElements;
import WebElements.LoginElements;
import WebElements.OrdersElements;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OrderSteps {
	

	WebDriverHooks hooks = new WebDriverHooks();

	WebDriver driver = hooks.getdriver();

	KeyValueDataProvider keys = new KeyValueDataProvider();

	 Actions keyBoard = new Actions(driver);

	@When("user should be one order landing page")
	public void user_should_be_one_order_landing_page() throws Exception {
		String ExceptedMassage = "Are you sure you want to login ?";
		
		// login first
		Liabrary.Send_Value(LoginElements.dbcode.findelement(driver), keys.getDBcode());
		Liabrary.Send_Value(LoginElements.userid.findelement(driver), keys.getuserid());
		Liabrary.Send_Value(LoginElements.pin.findelement(driver), keys.getpin());
		Liabrary.Send_Value(LoginElements.password.findelement(driver), keys.getpassword());
		Thread.sleep(15000);
		Liabrary.Click(LoginElements.loginbtn.findelement(driver));
		Thread.sleep(2000);
		
		try {
			WebElement AlertMessage= (LoginElements.anotheruserlogin.findelement(driver));
			
			if (AlertMessage.isDisplayed()){
				Thread.sleep(5000);
				Liabrary.Click(LoginElements.clickonyes.findelement(driver));
				Thread.sleep(2500);
			}
		}
		catch(Exception e) {
			System.out.println("You are the first user for login----Hence POP up not display...contineu");
		}
		
		
		Thread.sleep(2000);
		Liabrary.Mouse_Action_(OrdersElements.Transaction.findelement(driver), driver);
		Thread.sleep(2500);
		Liabrary.Mouse_click(OrdersElements.OrderClick.findelement(driver), driver);
		Thread.sleep(2500);
		}
		
	@When("^verify the page title \"([^\"]*)\"$")
	public void verify_the_page_title(String Expectedtitle) throws Exception {

		Assert.assertEquals(OrdersElements.PageTitle.findelement(driver).getText(), Expectedtitle);
		Thread.sleep(5000);

	}

	@When("click on view button")
	public void click_on_view_button() throws Exception {

		Liabrary.Click(OrdersElements.OrderView.findelement(driver));
		Thread.sleep(5000);

	}

	@When("click on OrderTab")
	public void click_on_order_tab() throws Exception {
		Liabrary.Click(OrdersElements.OrderTabClick.findelement(driver));
		Thread.sleep(5000);
	}

	@When("click on cancelOrder icon from Action column")
	public void click_on_cancel_order_icon_from_action_column() throws Exception {
		Assert.assertEquals(OrdersElements.ActionColumn.findelement(driver).getText(), "Actions");
		Thread.sleep(5000);
		Liabrary.Click(OrdersElements.CancelIcon.findelement(driver));
		Thread.sleep(5000);
		Assert.assertEquals(OrdersElements.CancelPageTitle.findelement(driver).getText(), "Cancel Order");
		Thread.sleep(5000);
	}

	@When("cancel the first product")
	public void cancel_the_first_product() throws Exception {
		System.out.println(OrdersElements.FirstUserCode.findelement(driver).getText());
		Thread.sleep(5000);
		Liabrary.Click(OrdersElements.FirstProductCancel.findelement(driver));
		Thread.sleep(5000);

	}

	@When("select the cancel reason")
	public void select_the_cancel_reason() throws Exception {
		Liabrary.Click(OrdersElements.CancelReasonSelect.findelement(driver));
		Thread.sleep(5000);
		System.out.println(OrdersElements.ReasonCaptcha.findelement(driver).getText());
		Thread.sleep(5000);

	}

	@When("Click on save button")
	public void click_on_save_button() throws Exception {
		Liabrary.Click(OrdersElements.Save.findelement(driver));
		Thread.sleep(15000);
	}

	@When("click on yes button from confirmation popup")
	public void click_on_yes_button_from_confirmation_popup() throws Exception {
		String ActualFunction = (OrdersElements.CancelPopupTitle.findelement(driver).getText());
		String ExceptedFunction = "Cancel Order";
		Assert.assertEquals(ActualFunction, ExceptedFunction);
		if (ActualFunction == ExceptedFunction) {
			System.out.println("Popup Page Title Is Matched");
		} else {
			System.out.println("Popup Page Title is not Matched");
		}
		Thread.sleep(15000);
		Liabrary.Click(OrdersElements.CancelPopupYesButton.findelement(driver));
		Thread.sleep(5000);

	}

	@Then("check successfully cancelorder message")
	public void check_successfully_cancelorder_message() throws Exception {
		String ExceptedFunction = "Product Cancelled";
		String ActualFunction = (OrdersElements.CancelToastMessage.findelement(driver).getText());

		Assert.assertEquals(ActualFunction, ExceptedFunction);
		if (ActualFunction == ExceptedFunction) {
			System.out.println("Toast Message is correct");
		} else {
			System.out.println("Toast Message is not correct");
		}
		Thread.sleep(15000);
	}

	@When("cancel the all product and select reason")
	public void cancel_the_all_product_and_select_reason() throws Exception {

		List<WebElement> Allproduct = (OrdersElements.AllProductCancel.findelements(driver));
		int totalsizes = Allproduct.size();
		System.out.println(totalsizes);
		for (int i2 = 0; i2 < totalsizes; i2++) {
			Allproduct.get(i2).click();
			Thread.sleep(5000);
			Liabrary.Click(OrdersElements.CancelReasonSelect.findelement(driver));
			Thread.sleep(5000);
		}
	}

	@When("Create PO Bill clickable and Open New Orders screen")
	public void create_po_bill_clickable_and_open_new_orders_screen() throws Exception {
		Liabrary.Click(OrdersElements.createPoAndBill.findelement(driver));
		Thread.sleep(5000);

	}

	@When("on that the Page Caption New Order")
	public void on_that_the_page_caption_new_order() throws Exception {
		OrdersElements.getOrderCaption.findelement(driver).getText();
		Thread.sleep(5000);
		Assert.assertTrue(OrdersElements.getOrderCaption.findelement(driver).getText(), true);
		Thread.sleep(5000);
		System.out.println(OrdersElements.getOrderCaption.findelement(driver).getText());
		Thread.sleep(5000);
	}

	@When("user select the account from dropdown")
	public void user_select_the_account_from_dropdown() throws Exception {

		Liabrary.Click(OrdersElements.selectionListOutlet.findelement1(driver));
		Thread.sleep(5000);
		Liabrary.Send_Value(OrdersElements.enterOutlet.findelement(driver), "SH");
		Thread.sleep(5000);
		List<WebElement> outletSelection = OrdersElements.allOutlet.findelements(driver);
		Thread.sleep(5000);
		for (WebElement outletSelected : outletSelection) {
			if (outletSelected.getText().equalsIgnoreCase("SHIVAM TRADER")) {
				
				outletSelected.click();
				break;
			}
			
		}
		Thread.sleep(5000);
	}

	@When("click on Add product button Product select and enter bill qty")
	public void click_on_add_product_button_product_select_and_enter_bill_qty() throws Exception {
			Liabrary.Click(OrdersElements.clickAddProduct.findelement(driver));
		  	Thread.sleep(2000);
			Liabrary.Click(OrdersElements.ProductAdd1.findelement(driver));
			Thread.sleep(2000);
			Liabrary.Click(OrdersElements.selectMRPDrop1.findelement(driver));
			Thread.sleep(2000);
			Liabrary.Click(OrdersElements.selectMRP1.findelement(driver));
			Thread.sleep(2000);
			Liabrary.Send_Value(OrdersElements.enterQty1.findelement(driver), "17");
			Thread.sleep(2000);
			Liabrary.Click(OrdersElements.selectside1.findelement(driver));
			Thread.sleep(2000);
			Liabrary.Click(OrdersElements.clickAddProduct.findelement(driver));
			Thread.sleep(2000);
			Liabrary.Click(OrdersElements.ProductAdd2.findelement(driver));
			Thread.sleep(2000);
			Liabrary.Click(OrdersElements.selectMRPDrop2.findelement(driver));
			Thread.sleep(2000);
			Liabrary.Click(OrdersElements.selectMRP2.findelement(driver));
			Thread.sleep(2000);
			Liabrary.Send_Value(OrdersElements.enterQty2.findelement(driver), "8");
			Thread.sleep(2000);
			Liabrary.Click(OrdersElements.selectside2.findelement(driver));
			Thread.sleep(2500);
		}
	
	@When("click on saveOrders button Save orders should be displayed in orders gird status source Manual, Serving status should be open")
	public void click_on_save_orders_button_save_orders_should_be_displayed_in_orders_gird_status_source_manual_serving_status_should_be_open() throws Exception {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		String ordersSeriesNo ;
		ordersSeriesNo = (OrdersElements.newOrdersSeriesNumber.findelement(driver).getText());
		Thread.sleep(2000);
		Liabrary.Click(OrdersElements.saveAsOrderButton.findelement(driver));
		Thread.sleep(2000);
		List<WebElement> saveOrdersNo = (OrdersElements.gridOrderNo.findelements(driver));
		for(WebElement OrderNo:saveOrdersNo) {
			
			if((OrderNo.getText()).equalsIgnoreCase(ordersSeriesNo)) {
				System.out.println(OrderNo.getText());
				Thread.sleep(2000);
				System.out.println(OrdersElements.servicingStatus.findelement(driver).getText());
				Thread.sleep(2000);
				System.out.println(OrdersElements.OrderSource.findelement(driver).getText());
				Thread.sleep(2000);
				break;
			}
		}
		Thread.sleep(2000);
		
		
	}
	@When("click on Alt + V button")
	public void click_on_alt_v_button() throws Exception {
	
	 keyBoard.click().keyDown(Keys.ALT).sendKeys("V").build().perform();
	 Thread.sleep(2500);
	}

	@When("click On Alt + C and Open New Orders screen")
	public void click_on_alt_c_and_open_new_orders_screen() throws Exception {
	keyBoard.click().keyDown(Keys.ALT).sendKeys("c").build().perform();
	Thread.sleep(5000);
	}
	
	
	

	@When("Click On Alt + O and outlet name select from dropdown")
	public void click_on_alt_o_and_outlet_name_select_from_dropdown() throws Exception {
		//keyBoard.click().keyDown(Keys.ALT).sendKeys("o").build().perform();
	    Thread.sleep(5000);
	    Liabrary.Click(OrdersElements.selectOneOutlet.findelement(driver));
	    Thread.sleep(5000);
	    keyBoard.click().keyUp(Keys.TAB).build().perform();
	    Thread.sleep(5000);
	}

	@When("Click on Alt + P and Product select and enter bill qty")
	public void click_on_alt_p_and_product_select_and_enter_bill_qty() throws Exception {
		Liabrary.Click(OrdersElements.beatCloseButton.findelement(driver));
		Thread.sleep(5000);
	   keyBoard.click().keyDown(Keys.ALT).sendKeys("p").build().perform();
	   Thread.sleep(2500);
	   Liabrary.Click(OrdersElements.ProductAdd1.findelement(driver));
	   Thread.sleep(2000);
	   Liabrary.Click(OrdersElements.selectMRPDrop1.findelement(driver));
	   Thread.sleep(2500);
	   Liabrary.Click(OrdersElements.selectMRP1.findelement(driver));
	   Thread.sleep(2500);
	   Liabrary.Send_Value(OrdersElements.enterQty1.findelement(driver), "24");
	   Thread.sleep(2500);
	   keyBoard.click().keyUp(Keys.TAB).build().perform();
	   Thread.sleep(2500);
	   Liabrary.Click(OrdersElements.beatCloseButton.findelement(driver));
		Thread.sleep(5000);
	   
	   
	}

	@When("Click on Alt + S and Orders Save.")
	public void click_on_alt_s_and_orders_save() throws Exception {
	   keyBoard.click().keyDown(Keys.ALT).sendKeys("S").build().perform();
	   Thread.sleep(25000);
	}
	@When("outlet name select from dropdown")
	public void outlet_name_select_from_dropdown() throws Exception {
			Liabrary.Click(OrdersElements.selectionListOutlet.findelement1(driver));
			Thread.sleep(5000);
		    Liabrary.Click(OrdersElements.selectOneOutlet.findelement(driver));
		    Thread.sleep(5000);
	}

	@When("Click on Alt + B and select series")
	public void click_on_alt_b_and_select_series() throws Exception {
		Liabrary.Click(OrdersElements.ConvertToBillButton.findelement(driver));
		Thread.sleep(5000);
	
	}
	@When("Check General Setup and select value No and check single converts to bill cd is disable")
	public void check_general_setup_and_select_value_no_and_check_single_converts_to_bill_cd_is_disable() throws Exception {
		boolean CDTextbox=(OrdersElements.EnterCDPer.findelement(driver)).isEnabled();
	
			Liabrary.Click(GeneralStepElements.toolsButton.findelement(driver));
			Thread.sleep(2500);
			Liabrary.Click(GeneralStepElements.generalSetupButton.findelement(driver));
			Thread.sleep(2500);
			Liabrary.Click(GeneralStepElements.generalSetupVeiw.findelement(driver));
			Thread.sleep(2500);
			Liabrary.Click(GeneralStepElements.saleDropdown.findelement(driver));
			Thread.sleep(2500);
			String SelectNo = (GeneralStepElements.cdSelectValue.findelement(driver)).getText();
			
			if(CDTextbox) {
				Assert.assertEquals(SelectNo, "Yes");
				
			
			}
			else
			{
				Assert.assertEquals(SelectNo, "No");
			}
			
		
		
		
		
		
	}

	@When("Check General Setup and select value Yes and check single converts to bill cd is enable")
	public void check_general_setup_and_select_value_yes_and_check_single_converts_to_bill_cd_is_enable() {
		
		
	}





}
