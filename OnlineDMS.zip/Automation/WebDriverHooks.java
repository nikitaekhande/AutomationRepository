package Hooks;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Utility.KeyValueDataProvider;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;

public class WebDriverHooks {
	KeyValueDataProvider key=new KeyValueDataProvider();
	
	public static WebDriver driver;
	
	@Before
    public void setUp() throws Exception {
		WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        Thread.sleep(2000);
        driver.get(key.getBaseURL());
       
    }

    @After
    public void tearDown() {
    	driver.close();
        

}
    
    public WebDriver getdriver() {
    	return driver;
    }
    
}
