package CucumberOptions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

public class StockPositionSummaryTestRunner {

		@RunWith(Cucumber.class)
		@CucumberOptions(
		    features = "src/test/resources/FeatureFiles/StockSummaryPostion.feature",
		    glue = "StepDefinations/StockSummaryPostionSteps",
		    plugin = {"pretty", "html:target/cucumber-reports"}
		)
		public class TestRunner {
			
		}

	}

