package StepDefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import Utility.Liabrary;
import WebElements.DashboardElements;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import Hooks.WebDriverHooks;
public class PaymentSteps {

	WebDriver driver=WebDriverHooks.driver;
	
	
	@Given("the user is on the Transaction menu")
	public void the_user_is_on_the_transaction_menu() throws Exception {
		Liabrary.Mouse_Action_(DashboardElements.transactionMenu.findelement(driver), driver);
		Thread.sleep(3000);
	   
	}

	@When("the user clicks on the Payment option")
	public void the_user_clicks_on_the_payment_option() throws Exception {
	   Liabrary.Mouse_click(DashboardElements.paymenttransaction.findelement(driver), driver);
	   Thread.sleep(2000);
	}

	@When("the user clicks on the View button")
	public void the_user_clicks_on_the_view_button() {
		Liabrary.Click(DashboardElements.viewbtn.findelement(driver));
	   
	}

	@When("the user clicks on the +Add button")
	public void the_user_clicks_on_the_add_button() {
		Liabrary.Click(DashboardElements.addbtn.findelement(driver));
	}

	@Then("the payment page open and header text should be {string}")
	public void the_header_text_should_be(String expectedHeader) {
		String actualdHeader=DashboardElements.newPaymentHeadertxt.findelement(driver).getText();
		Assert.assertEquals(expectedHeader, actualdHeader);
	    
	}


}
