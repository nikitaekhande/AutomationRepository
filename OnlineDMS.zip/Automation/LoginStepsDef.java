package StepDefinations;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import Hooks.WebDriverHooks;
import Utility.Liabrary;
import Utility.KeyValueDataProvider;
import WebElements.LoginElements;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;


public class LoginStepsDef {
	
	KeyValueDataProvider key=new KeyValueDataProvider();
	WebDriverHooks hooks=new WebDriverHooks();
	
	WebDriver driver=hooks.getdriver();


    @Given("User is on the login page of DMS Application")
    public void user_is_on_login_page() throws Exception {
       
    /*	WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get(key.getBaseURL());
        driver.manage().window().maximize();*/
    	System.out.println("login page");
    }

    @When("User Enters Valid credentials with DB code {string}, UserID {string}, Password {string}, and PinCode {string}")
    public void user_enters_valid_credentials(String dbCode, String userId, String password, String pinCode) throws Exception {
    	
    	Liabrary.Send_Value(LoginElements.dbcode.findelement(driver), dbCode);
    	Liabrary.Send_Value(LoginElements.userid.findelement(driver), userId);
    	Liabrary.Send_Value(LoginElements.password.findelement(driver), password);
    	Liabrary.Send_Value(LoginElements.pin.findelement(driver), pinCode);
    	Thread.sleep(5000);
    	
      
    }
    @When("user will enter the captcha")
    public void user_enter_captch() throws AWTException, Exception {
    	
    	WebElement element=LoginElements.captchimagae.findelement(driver);
        File trg = element.getScreenshotAs(OutputType.FILE);
        String path="C:\\Users\\10261\\eclipse-workspace\\OnlineDMS_Automation_Final\\Capcha\\element_screenshot.png";
        Thread.sleep(2000);
        File src = new File(path);
        FileUtils.copyFile(trg, src);
        
        Tesseract tesseract = new Tesseract();

        try {
            // Perform OCR on the image
            String extractedText = tesseract.doOCR(new File(path));

            // Print the extracted text
            System.out.println("Extracted Text:");
            System.out.println(extractedText);
        } catch (TesseractException e) {
            // Handle Tesseract exception
            e.printStackTrace();
        }
    }


	@When("User Clicks on the login button")
    public void user_clicks_login_button() throws InterruptedException {
		Thread.sleep(7000);
    	Liabrary.Click(LoginElements.loginbtn.findelement(driver));
    	
    }

    @Then("validate the login message is {string}")
    public void validate_login_message(String expectedMessage) {
       String actualMessage=LoginElements.loginsuccessMSG.findelement(driver).getText();
       Assert.assertEquals(expectedMessage, actualMessage);
  
    }
}

	 
	 

