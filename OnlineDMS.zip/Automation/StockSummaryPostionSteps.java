package StepDefinations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import Hooks.WebDriverHooks;
import Utility.KeyValueDataProvider;
import Utility.Liabrary;
import WebElements.LoginElements;
import WebElements.StockPositionSummaryElement;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StockSummaryPostionSteps {
	
	WebDriverHooks hooks = new WebDriverHooks();
	WebDriver driver = hooks.getdriver();
	KeyValueDataProvider keys = new KeyValueDataProvider();
	
	
	
	

	@When("user should be land on dashboard paged.")
	public void user_should_be_land_on_dashboard_paged() throws Exception {
		Liabrary.Send_Value(LoginElements.dbcode.findelement(driver), keys.getDBcode());
		Liabrary.Send_Value(LoginElements.userid.findelement(driver), keys.getuserid());
		Liabrary.Send_Value(LoginElements.password.findelement(driver), keys.getpassword());
		Liabrary.Send_Value(LoginElements.pin.findelement(driver), keys.getpin());
		Thread.sleep(15000);
		Liabrary.Click(LoginElements.loginbtn.findelement(driver));
		Thread.sleep(3500);
	}

	@When("landing on reports menu and click on reports menu")
	public void landing_on_reports_menu_and_click_on_reports_menu() throws Exception {
		Liabrary.Mouse_click(StockPositionSummaryElement.Reports.findelement(driver), driver);
		Thread.sleep(3500);

	}

	@When("click on stock summary reports")
	public void click_on_stock_summary_reports() throws Exception {
		Liabrary.Mouse_click(StockPositionSummaryElement.StockPositionSummary.findelement(driver), driver);
		Thread.sleep(2500);

	}

	@When("click on check box as on date button")
	public void click_on_check_box_as_on_date_button() throws Exception {
		Liabrary.Click(StockPositionSummaryElement.AsOnDate.findelement(driver));
		Thread.sleep(3500);
	}

	@When("click on apply button")
	public void click_on_apply_button() throws Exception {

		Liabrary.Click(StockPositionSummaryElement.Applybutton.findelement(driver));
		Thread.sleep(3500);

	}

	@Then("reports grid list Data present")
	public void reports_grid_list_Data_present() throws Exception {
		
		boolean gridRowQuantity = (StockPositionSummaryElement.GridDataRowQty.findelement(driver).isDisplayed());

	}

}
