package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class KeyValueDataProvider {
	//C:\Users\10261\eclipse-workspace\OnlineDMS_Automation_Final\Confiq_Test_Data\config.properties
	private static Properties pro;
	
	public String getBaseURL() throws Exception {
		String confiqpath=System.getProperty("user.dir")+"\\Confiq_Test_Data\\config.properties";
		File f=new File(confiqpath);
		FileInputStream file=new FileInputStream(f);
		pro=new Properties();
		pro.load(file);
		return pro.getProperty("BaseURL");
	}
	
	public String getDBcode() {
		return pro.getProperty("dbcode_a");
	}
	public String getuserid() {
		return pro.getProperty("userid_a");
	}
	public String getpin() {
		return pro.getProperty("pin_a");
	}
	public String getpassword() {
		return pro.getProperty("pass_a");
	}
	

}
