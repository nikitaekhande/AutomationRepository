package Utility;


import java.io.File;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.hc.core5.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class Liabrary {
	
	public static void Send_Value(WebElement element , String value) {
		
		try {
			element.sendKeys(value);
		}
		catch(Exception e) {
			
			System.out.println("Unable to send value- i.e= "+ value);
			
		}
	}
	
		public static void Click(WebElement element) {
			
			try {
				element.click();
			}
			catch(Exception e) {
				
				System.out.println("Button is not clickable= "+ element.getText());
				
			}
		
	}

		public static void MouseAction(WebElement element,WebDriver driver) {
			

			try {
				Actions action =new Actions(driver);
				action.moveToElement(element).click().build().perform();
			}
			catch(Exception e){
				System.out.println(e.getMessage());
		
	}
			
			
		}
		

		public static void Mouse_Action_(WebElement element,WebDriver driver) {
			
			try {
				Actions action =new Actions(driver);
				action.moveToElement(element).build().perform();
			}
			catch(Exception e){
				System.out.println(e.getMessage());
				
			}
		}
		public static void Mouse_click(WebElement element,WebDriver driver) {
			
			try {
				Actions action =new Actions(driver);
				action.moveToElement(element).click().build().perform();
			}
			catch(Exception e){
				System.out.println(e.getMessage());
		
	}
		}
		public static void Scroll_to_Element(WebElement element,WebDriver driver) {
			try {
			 JavascriptExecutor jse1= (JavascriptExecutor)driver;
			 jse1.executeScript("arguments[0].scrollIntoView(true);", element);
			}
			catch(Exception e) {
				System.out.println(e.getMessage());}
			}

		public static void Clicks(List<WebElement> elements) {
		for (WebElement element : elements) {
            try {
                // Click on the element
                element.click();
            } catch (Exception e) {
                // If the element is not clickable, print a message
                System.out.println("Button is not clickable: " + e.getMessage());
            }
		}
	
		
		}	
	    public static String processCaptchaImage(File captchaFile) {
	    	String result = null;
	    	 Tesseract tesseract = new Tesseract();
	    	 try {
	    		 result  = tesseract.doOCR(captchaFile);
	    	 }catch (TesseractException e) {
	             System.err.println("Error while reading image: " + e.getMessage());
	         }
			return result;
		}

}
