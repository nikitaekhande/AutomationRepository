package WebElements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public enum DashboardElements {
	

	transactionMenu("//input[@id='DBCode']"),
	paymenttransaction("//input[@id='UserID']"),
	viewbtn("//input[@id='Password']"),
	addbtn("//input[@id='Pin']"),
	newPaymentHeadertxt("//Button[text()='Continue']");
	
	private String element;
	
	DashboardElements(String element){
		this.element=element;
	}
	
	public WebElement findelement(WebDriver driver) {
		
		return driver.findElement(By.xpath(element));
	}

}
