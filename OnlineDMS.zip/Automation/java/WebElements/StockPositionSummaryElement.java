package WebElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public enum StockPositionSummaryElement {

	Reports("//a[@class='nav-link menuhide']//span[contains(text(),'Reports')]"),
	StockPositionSummary("//li[@class='dms-reports-sub-menu-item']//label[contains(text(),'Stock Position Summary')][1]"),
	EmptyScreen("(//label[contains(text(),'Select appropriate parameter at left side panel first and then click to 'Apply' button to see the report.')])[1]"),
	AsOnDate("//input[@type ='checkbox']"),
	Applybutton("//button[@class='dms-button dms-primary-button dms-large-button']|//button[normalize-space()='pply']"),
	GridDataRowQty("//td[@data-kendo-grid-column-index='6']");
	
	
	private String element;
	
	StockPositionSummaryElement(String element){
		this.element=element;
	}
	
	public WebElement findelement(WebDriver driver) {
		
		return driver.findElement(By.xpath(element));
	}
	
	public List<WebElement> findelements(WebDriver driver) {
		
		return driver.findElements(By.xpath(element));
	}
	
	
}


