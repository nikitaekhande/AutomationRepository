package WebElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public enum GeneralStepElements {
	toolsButton("//a//span[normalize-space()='Tools']"),
	generalSetupButton("//li//a[normalize-space()='General Setup']"),
	generalSetupVeiw("//button[contains(text(),'iew')]"),
	saleDropdown("accordianIds1"),
	cashDiscountClick("66808722-237b-4d48-8b06-0dc59c3b1ca5"),
	cdSelectValue("//span[@id='66808722-237b-4d48-8b06-0dc59c3b1ca5']//span[@class='k-input-value-text']"),
	starDiscountClick("51a239e7-abbe-49bf-a712-cb4cdebfcf8d"),
	starSelectValue("//span[@id='51a239e7-abbe-49bf-a712-cb4cdebfcf8d']//span[@class='k-input-value-text']");
private String element;
	
	GeneralStepElements(String element){
		this.element=element;
	}
	
	public WebElement findelement(WebDriver driver) {
		
		return driver.findElement(By.xpath(element));
	}
	
	public List<WebElement> findelements(WebDriver driver) {
		
		return driver.findElements(By.xpath(element));
	}

	public WebElement findelement1(WebDriver driver) {
		
		return driver.findElement(By.id(element));
	}
	
	
}

