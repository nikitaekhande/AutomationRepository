package WebElements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public enum LoginElements {
	
	dbcode("//input[@id='DBCode']"),
	userid("//input[@id='UserID']"),
	password("//input[@id='Password']"),
	pin("//input[@id='Pin']"),
	loginbtn("//Button[text()='Continue']"),
	captchimagae("//canvas[@id='captcahCanvas']"),
	captcha("//input[@id='userCaptchaInput']"),
	loginsuccessMSG("//div[text()=' Login Successful ! ']"),
	anotheruserlogin("//h2[contains(text(),'Are you sure you want to login ?')]"),
	clickonyes("//button[contains(text(),'es')]");
	
	private String element;
	
	LoginElements(String element){
		this.element=element;
	}
	
	public WebElement findelement(WebDriver driver) {
		
		return driver.findElement(By.xpath(element));
	}
}
