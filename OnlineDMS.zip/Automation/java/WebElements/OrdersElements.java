package WebElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public enum OrdersElements {
	
		
		Transaction("//span[normalize-space()='Transactions']"),
		OrderClick("//a[normalize-space(text()) = 'Orders']"),
		PageTitle("//h3[contains(text(),'Orders')]"),
		OrderView("//button[contains(text(),'iew')]"),
		OrderTabClick("//div/p[contains(text(),' Orders ')]"),
		ActionColumn("//span[contains(text(),'Actions')]"),
		CancelIcon("//tr[@aria-rowindex='2']//span[@class='ng-star-inserted']/img[@src='/assets/icons/cancel.svg']"),
		CancelPageTitle("//div/h3[contains(text(),'Cancel Order')]"),
		FirstUserCode("//tr[@data-kendo-grid-item-index='0']/td[@aria-colindex='2']"),
		FirstProductCancel("//tr[@data-kendo-grid-item-index='0']//span[contains(text(),'Cancel Product')]"),			
		CancelReasonSelect("//div[@class='cancel-reason-pop-up-item ng-star-inserted'][2]"),
		ReasonCaptcha("//tr[@data-kendo-grid-item-index='0']//td[@aria-colindex='14']//span[@class='ng-star-inserted']"),
		Save("//div[@class='dms-section-bottom-bar']//button[contains(text(),'ave')]"),
		CancelPopupTitle("//div[@id='drowerTab' ]/h3[contains(text(),'Cancel Order')]"),
		CancelPopupYesButton("//div[@class='modal-footer' ]//button/div[contains(text(),'es')]"),
		CancelToastMessage("//div[@class='ant-notification-notice-content success-toast ng-star-inserted']//span/div[contains(text(),'Product Cancelled')]"),
		AllProductCancel("//td[@class='k-grid-content-sticky k-touch-action-auto ng-star-inserted']//span[contains(text(),'Cancel Product')]"),
		createPoAndBill("//button[contains(text(),'reate PO & Bill')]"),
		getOrderCaption("//label[contains(text(),'New Order')]"),
		beatCloseButton("//button[contains(text(),'Close')]"),
		selectionListOutlet("accountList"),
		enterOutlet("//input[@placeholder='Select Outlet']"),
		allOutlet("//li[@role='option']//span[@style='width: 300px; font-size: 12px;']"),
		selectOneOutlet("//li[@index='0']//following-sibling::span[@class='k-table-td ng-star-inserted']"),
		clickAddProduct("//td/span[contains(text(),' Add Product (alt + P) ')]"),
		ProductAdd1("//li[@role='option'][1]//span[@class = 'k-table-td ng-star-inserted']"),
		selectMRPDrop1("//td[@aria-colindex='5'][1]//button[@aria-label='Select']"),
		selectMRP1("//td[@aria-colindex='5'][1]//span[@class='k-input-inner']//span[@class='k-input-value-text'][1]"),
		enterQty1("//tr[@data-kendo-grid-item-index='0'][1]//td[@aria-colindex='8'][1]//input[@class='ant-input ng-star-inserted']"),
		selectside1("//tr[@data-kendo-grid-item-index='0']//td[@aria-colindex='9']"),	
		ProductAdd2("//li[@role='option'][3]//span[@class = 'k-table-td ng-star-inserted']"),
		selectMRPDrop2("//tr[@data-kendo-grid-item-index='1']//following-sibling::td[@aria-colindex='5']//button[@aria-label='Select']"),
		selectMRP2("//tr[@data-kendo-grid-item-index='1']//following-sibling::td[@aria-colindex='5']//span[@class='k-input-inner']//span[@class='k-input-value-text'][1]"),
		enterQty2("//tr[@data-kendo-grid-item-index='1']//td[@aria-colindex='8']//input[@class='ant-input ng-star-inserted']"),
		selectside2("//tr[@data-kendo-grid-item-index='1']//td[@aria-colindex='9']"),
		saveAsOrderButton("//button[@type='button']//label[normalize-space()='Order' ]"),
		newOrdersSeriesNumber("//dms-terminology-enabled-label[@labelvalue='Order No']//following-sibling::span[@class='dms-subvalue']"),
		gridOrderNo("//td[@data-kendo-grid-column-index='2']"),
		servicingStatus("//td[@data-kendo-grid-column-index='7']"),
		OrderSource("//td[@data-kendo-grid-column-index='3']"),
		ConvertToBillButton("//div[@class='col-md-auto justify-content-end']//u[normalize-space(text()) = 'B']"),
		EnterCDPer("//td[@data-kendo-grid-column-index='5']//input[@id='inputSelectorComponent']"),
		EnterStarPer("//td[@data-kendo-grid-column-index='7']//input[@id='inputSelectorComponent']");
		
	
	private String element;
	
	OrdersElements(String element){
		this.element=element;
	}
	
	public WebElement findelement(WebDriver driver) {
		
		return driver.findElement(By.xpath(element));
	}
	
	public List<WebElement> findelements(WebDriver driver) {
		
		return driver.findElements(By.xpath(element));
	}

	public WebElement findelement1(WebDriver driver) {
		
		return driver.findElement(By.id(element));
	}
	
	
}